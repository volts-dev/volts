package rpc

/*
#模板全局默认变量
	micro
	│
	├─cmd 命令接口目录
	├─transport 通讯接口目录
	│  ├─grpc
	│  ├─http
	│  └─src 资源文件
	│
	├─deploy 部署文件目录
	│
	├─main.go 主文件
	└─main.ini 配置文件
*/
